<?php

/**
 * Class VirtualWireRQueryContext
 * @property VirtualWire $object
 * @ignore
 */
class VirtualWireRQueryContext extends RQueryContext
{

}