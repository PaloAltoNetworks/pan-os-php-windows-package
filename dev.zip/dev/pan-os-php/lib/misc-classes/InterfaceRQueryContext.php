<?php

/**
 * Class InterfaceRQueryContext
 * @property EthernetInterface|VlanInterface|LoopbackInterface|TunnelInterface $object
 * @ignore
 */
class InterfaceRQueryContext extends RQueryContext
{

}


