<?php

/**
 * Class RoutingRQueryContext
 * @property VirtualRouter $object
 * @ignore
 */
class RoutingRQueryContext extends RQueryContext
{

}