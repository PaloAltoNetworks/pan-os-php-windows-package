<?php

/**
 * Class ZoneRQueryContext
 * @property Zone $object
 * @ignore
 */
class ZoneRQueryContext extends RQueryContext
{

}