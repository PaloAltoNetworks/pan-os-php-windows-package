<?php

/**
 * Class TagRQueryContext
 * @property Tag $object
 * @ignore
 */
class TagRQueryContext extends RQueryContext
{

}