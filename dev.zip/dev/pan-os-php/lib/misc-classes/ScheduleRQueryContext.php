<?php

/**
 * Class ScheduleRQueryContext
 * @property Schedule $object
 * @ignore
 */
class ScheduleRQueryContext extends RQueryContext
{

}