<?php

/**
 * Class ServiceRQueryContext
 * @property Service|ServiceGroup $object
 * @ignore
 */
class ServiceRQueryContext extends RQueryContext
{

}