<?php

/**
 * Class SecProfRQueryContext
 * @property SecurityProfileURL $object
 * @ignore
 */
class SecurityProfileRQueryContext extends RQueryContext
{

}