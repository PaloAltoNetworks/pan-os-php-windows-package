<?php

/**
 * Class RuleRQueryContext
 * @property Rule|SecurityRule|NatRule|PbfRule|AppOverrideRule|CaptivePortalRule|AuthenticationRule|QoSRule $object
 * @ignore
 */
class RuleRQueryContext extends RQueryContext
{

}