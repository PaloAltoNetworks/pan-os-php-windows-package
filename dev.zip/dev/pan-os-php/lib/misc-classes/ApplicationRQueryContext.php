<?php

/**
 * Class ApplicationRQueryContext
 * @property App $object
 * @ignore
 */
class ApplicationRQueryContext extends RQueryContext
{

}