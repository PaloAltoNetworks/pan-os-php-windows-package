<?php

/**
 * Class AddressRQueryContext
 * @property Address|AddressGroup $object
 * @ignore
 */
class AddressRQueryContext extends RQueryContext
{

}