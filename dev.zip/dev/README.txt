
Pre-packaged PHP for PAN-OS-PHP

unzip folder 'dev' and move it to c:\

run ‘run-once-to-setup.bat’ then ‘console.bat’ to start using it.

‘update-pan-os-php.bat’ from time to time to get latest version
